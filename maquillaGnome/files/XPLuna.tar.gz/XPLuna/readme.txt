[EN] This is my first theme made from original Microsoft's theme "Luna" for
     WinXP. The Metacity theme is Lunacity Blue. I uploading this theme
     WITHOUT ANY WARRANTIES, but if you found a bug here, report to my
     e-mail: dimatkachuk@yandex.ru. I will fix the bug and upload new version
     of theme.

[RU] Это - моя первая тема, собранная из оригинальной Microsoft'ской темы
     "Luna". Тема Metacity - Lunacity Blue. Я загружаю эту тему на сайт
     БЕЗ КАКИХ-ЛИБО ГАРАНТИЙ, но если вы заметили ошибку или глюк, пишите
     мне на e-mail: dimatkachuk@yandex.ru. Я исправлю ошибку и загружу новую
     версию темы.

[UK] Це моя перша тема, яку зроблено з оригінальної теми Microsoft'a "Luna".
     Тема Metacity - Lunacity Blue. Я завантажую цю тему на сайт БЕЗ БУДЬ-ЯКИХ
     ГАРАНТІЙ, але якщо ви помітили помилку, пишіть мені на
     e-mail: dimatkachuk@yandex.ru. Я виправлю помилку та надішлю на сайт нову
     версію темм.

This theme was made by Dmitry "Gnominator" Tkachuk.
Эта тема была сделана Дмитрием Ткачуком (Gnominator).
Цю тему було створено Дмитром Ткачуком (Gnominator).


I recommend GnomeXP icon theme for this GTK&Metacity theme.
Я рекомендую тему иконок GnomeXP для этой темы GTK&Metacity.
Я рекомендую тему іконок GnomeXP для цієї теми GTK&Metacity.
